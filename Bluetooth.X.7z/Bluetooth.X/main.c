/*
 * File:   main.c
 * Author: Tan Sang
 *
 * Created on December 9, 2020, 12:26 PM
 */

// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 16000000
unsigned char a;
void main(void) 
{
    TRISDbits.TRISD2 = 0x00;
    TRISCbits.TRISC1 = 1;
    TRISBbits.TRISB1 = 0;
    RD2 = 0;
    SYNC = 0;
    BRGH = 0;
    SPBRG = 25;
    SPEN = 1;
    TXEN = 1;
    TXREG = 0x41;
    __delay_ms(100);
    TXREG = 0x42;
    CREN = 1;
    PEIE = 1;
    GIE = 0;
    CREN = 1;
    RCIF= 0;
//    TXIF = 1;
//    TXIE = 1;
    while (1)
    {
        while (RCIF ==0);
        a = RCREG;
//        while(TXIF == 0);
//        TXREG = 0x41;
        while(TXIF == 0);
        TXREG = 'S';
        __delay_ms(10);
        while(TXIF == 0);
        TXREG = 'A';
        __delay_ms(10);
                while(TXIF == 0);
        TXREG = 'N';
        __delay_ms(10);
        while(TXIF == 0);
        TXREG = 'G';
        __delay_ms(10);
        while(TXIF == 0);
        TXREG = '\r';
        while (TXIF == 0);
        TXREG = '\n';
        while (TXIF == 0);
//        __delay_ms(50);
       RD2 = ~RD2;
//        __delay_ms(500);
        
    }
}

